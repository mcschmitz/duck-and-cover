import os
import numpy as np


def list_pictures(directory):
    return [os.path.join(root, f)
            for root, _, files in os.walk(directory) for f in files]

def get_old_picture(images, n):
    idx = np.random.randint(0, len(images))
    return images[idx]


def get_new_images(image_name, image_names, num_new_images):
    random_numbers = np.arange(len(image_names))
    np.random.shuffle(random_numbers)
    if int(num_new_images) > (len(image_names) - 1):
        num_new_images = len(image_names) - 1
    new_count = 0
    new_images = []
    for random_number in list(random_numbers):
        if image_names[random_number] != image_name:
            new_images.append(image_names[random_number])
            new_count += 1
            if int(new_count) > (int(num_new_images) - 1):
                break
    return new_images


def duplet_sampler(directory_path, output_path, num_old_images):
    classes = [d for d in os.listdir(directory_path) if os.path.isdir(os.path.join(directory_path, d))]
    all_images = []
    for class_ in classes:
        all_images += (list_pictures(os.path.join(directory_path, class_)))
    duplets = []
    for class_ in classes:
        image_names = list_pictures(os.path.join(directory_path, class_))
        for image_name in image_names:
            if 'new' not in image_name:
                continue
            new_image = image_name
            old_images = [img for img in image_names if 'new' not in img]
            old_image = get_old_picture(old_images, num_old_images)
            duplets.append(new_image + ',')
            duplets.append(old_image + '\n')

    f = open(os.path.join(output_path, "duplets.txt"), 'w')
    f.write("".join(duplets))
    f.close()


if __name__ == '__main__':
    # Instantiate the parser
    input_directory = 'data'
    output_directory = 'triplets'
    num_new_images = 1
    num_old_images = 1
    print("Input Directory: " + input_directory)
    print("Output Directory: " + output_directory)
    print("Number of Positive image per Query image: " + str(num_new_images))
    print("Number of Negative image per Query image: " + str(num_old_images))

    duplet_sampler(directory_path=input_directory, output_path=output_directory, num_old_images=num_old_images)
